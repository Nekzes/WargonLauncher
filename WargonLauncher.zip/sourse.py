import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from threading import Thread
import json
import sys
import subprocess
import base64
from io import BytesIO
import glob
from PIL import Image, ImageTk, ImageEnhance, ImageDraw
import colorsys
import time
import math
import random
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# Встроенные изображения (Base64)
ICON_BASE64 = """
iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAF
0WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0w
TXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRh
LyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEz
LTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3Jn
LzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0i
IiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRw
Oi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMu
YWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNv
bS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9z
VHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0Mg
MjAxOSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDI0LTAzLTE5VDIyOjQ3OjQ3KzAzOjAw
IiB4bXA6TW9kaWZ5RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgeG1wOk1ldGFkYXRh
RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBo
b3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2
LTIuMSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1m
YzM5ZjM5ZjM5ZjMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MGVjYmIzNDctYTIzNC00YTRi
LTljNGMtZmMzOWYzOWYzOWYzIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MGVj
YmIzNDctYTIzNC00YTRiLTljNGMtZmMzOWYzOWYzOWYzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6
U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1w
LmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1mYzM5ZjM5ZjM5ZjMiIHN0RXZ0OndoZW49IjIw
MjQtMDMtMTlUMjI6NDc6NDcrMDM6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rv
c2hvcCBDQyAyMDE5IChXaW5kb3dzKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9y
ZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIi
Pz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvK
ycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KR
kI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllY
V1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAf
Hh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAAAACwAAAAAAwADAAACBZQjmIAF
ADs=
"""

# Иконка мода (Base64)
MOD_ICON_BASE64 = """
iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAF
0WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0w
TXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRh
LyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEz
LTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3Jn
LzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0i
IiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRw
Oi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMu
YWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNv
bS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9z
VHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0Mg
MjAxOSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDI0LTAzLTE5VDIyOjQ3OjQ3KzAzOjAw
IiB4bXA6TW9kaWZ5RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgeG1wOk1ldGFkYXRh
RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBo
b3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2
LTIuMSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1m
YzM5ZjM5ZjM5ZjMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MGVjYmIzNDctYTIzNC00YTRi
LTljNGMtZmMzOWYzOWYzOWYzIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MGVj
YmIzNDctYTIzNC00YTRiLTljNGMtZmMzOWYzOWYzOWYzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6
U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1w
LmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1mYzM5ZjM5ZjM5ZjMiIHN0RXZ0OndoZW49IjIw
MjQtMDMtMTlUMjI6NDc6NDcrMDM6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rv
c2hvcCBDQyAyMDE5IChXaW5kb3dzKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9y
ZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIi
Pz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvK
ycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KR
kI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllY
V1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAf
Hh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAAAACwAAAAAAwADAAACBZQjmIAF
ADs=
"""

# Фоновое изображение (Base64)
BACKGROUND_BASE64 = """
iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAF
0WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0w
TXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRh
LyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDUgNzkuMTYzNDk5LCAyMDE4LzA4LzEz
LTE2OjQwOjIyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3Jn
LzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0i
IiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRw
Oi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMu
YWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNv
bS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9z
VHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0Mg
MjAxOSAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDI0LTAzLTE5VDIyOjQ3OjQ3KzAzOjAw
IiB4bXA6TW9kaWZ5RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgeG1wOk1ldGFkYXRh
RGF0ZT0iMjAyNC0wMy0xOVQyMjo0Nzo0NyswMzowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBo
b3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2
LTIuMSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1m
YzM5ZjM5ZjM5ZjMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MGVjYmIzNDctYTIzNC00YTRi
LTljNGMtZmMzOWYzOWYzOWYzIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MGVj
YmIzNDctYTIzNC00YTRiLTljNGMtZmMzOWYzOWYzOWYzIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6
U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1w
LmlpZDowZWNiYjM0Ny1hMjM0LTRhNGItOWM0Yy1mYzM5ZjM5ZjM5ZjMiIHN0RXZ0OndoZW49IjIw
MjQtMDMtMTlUMjI6NDc6NDcrMDM6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rv
c2hvcCBDQyAyMDE5IChXaW5kb3dzKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9y
ZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIi
Pz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvK
ycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KR
kI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllY
V1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAf
Hh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAAAACwAAAAAAwADAAACBZQjmIAF
ADs=
"""

class ModernButton(tk.Canvas):
    def __init__(self, master=None, **kwargs):
        self.text = kwargs.pop('text', '')
        self.hover_text = kwargs.pop('hover_text', None)
        self.command = kwargs.pop('command', None)
        self.style = kwargs.pop('style', 'TButton')
        self.original_padding = kwargs.pop('padding', 10)
        
        # Определяем цвета в зависимости от стиля
        if self.style == 'Launch.TButton':
            self.bg_color = "#4a90e2"  # accent_blue
            self.hover_color = "#357abd"  # hover_blue
            self.border_color = "#ffffff"  # Белая обводка для кнопки запуска
        elif self.style == 'Control.TButton':
            self.bg_color = "#112240"  # bg_blue
            self.hover_color = "#357abd"  # hover_blue
            self.border_color = "#4a90e2"  # border_color
        else:
            self.bg_color = "#112240"  # bg_blue
            self.hover_color = "#357abd"  # hover_blue
            self.border_color = None
            
        self.text_color = "#ffffff"  # text_color
        self.hover_text_color = "#a8d1ff"  # hover_text_color
        
        # Создаем canvas с прозрачным фоном
        super().__init__(master, 
                        highlightthickness=0,
                        bg="#0a192f",  # Используем темно-синий фон напрямую
                        **kwargs)
        
        # Привязываем события
        self.bind('<Enter>', self.on_enter)
        self.bind('<Leave>', self.on_leave)
        self.bind('<Button-1>', self.on_click)
        
        # Создаем кнопку
        self.create_button()
        
        # Для кнопки запуска добавляем обработчик изменения размера окна
        if self.style == 'Launch.TButton':
            self.bind('<Configure>', self.on_resize)
        
    def create_button(self):
        # Получаем размеры текста
        font = ('Segoe UI', 12 if self.style == 'Launch.TButton' else 10)
        text = self.hover_text if self.hover_text else self.text
        
        # Создаем временный label для измерения текста
        temp_label = tk.Label(self, text=text, font=font)
        temp_label.update()
        text_width = temp_label.winfo_reqwidth()
        text_height = temp_label.winfo_reqheight()
        temp_label.destroy()
        
        # Вычисляем размеры кнопки
        padding = self.original_padding
        if self.style == 'Launch.TButton':
            # Для кнопки запуска используем полную ширину родителя
            width = self.master.winfo_width()
            if width < 100:  # Минимальная ширина
                width = 100
        else:
            width = text_width + padding * 2
            
        height = text_height + padding * 2
        
        # Создаем скругленный прямоугольник
        radius = 10
        if self.border_color:
            # Сначала рисуем обводку
            self.button_border = self.create_rounded_rect(0, 0, width, height, radius, 
                                                        fill=self.border_color)
            # Затем рисуем фон с отступом
            if self.style == 'Launch.TButton':
                self.button_bg = self.create_rounded_rect(2, 2, width-4, height-4, radius, 
                                                        fill=self.bg_color)
            else:
                self.button_bg = self.create_rounded_rect(1, 1, width-2, height-2, radius, 
                                                        fill=self.bg_color)
        else:
            # Для кнопок без обводки просто рисуем фон
            self.button_bg = self.create_rounded_rect(0, 0, width, height, radius, 
                                                    fill=self.bg_color)
        
        # Создаем текст
        self.button_text = self.create_text(width/2, height/2,
                                          text=self.text,
                                          fill=self.text_color,
                                          font=font)
        
        # Устанавливаем размеры canvas
        self.configure(width=width, height=height)
        
    def create_rounded_rect(self, x1, y1, x2, y2, radius, **kwargs):
        points = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1
        ]
        return self.create_polygon(points, smooth=True, **kwargs)
        
    def on_enter(self, e):
        # Изменяем цвет фона
        self.itemconfig(self.button_bg, fill=self.hover_color)
        # Изменяем цвет текста
        self.itemconfig(self.button_text, fill=self.hover_text_color)
        # Изменяем текст если есть hover_text
        if self.hover_text:
            self.itemconfig(self.button_text, text=self.hover_text)
        
    def on_leave(self, e):
        # Возвращаем исходный цвет фона
        self.itemconfig(self.button_bg, fill=self.bg_color)
        # Возвращаем исходный цвет текста
        self.itemconfig(self.button_text, fill=self.text_color)
        # Возвращаем исходный текст
        self.itemconfig(self.button_text, text=self.text)
        
    def on_click(self, e):
        if self.command:
            self.command()

    def on_resize(self, event):
        if self.style == 'Launch.TButton':
            # Обновляем размер кнопки при изменении размера окна
            width = self.master.winfo_width()
            if width < 100:  # Минимальная ширина
                width = 100
            self.configure(width=width)
            # Обновляем размер фона и позицию текста
            self.coords(self.button_border, 0, 0, width, self.winfo_height())
            self.coords(self.button_bg, 2, 2, width-4, self.winfo_height()-4)
            self.coords(self.button_text, width/2, self.winfo_height()/2)

class PolLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("WargonLauncher [2.2] - Майнкрафт Мод Лаунчер")
        
        # Устанавливаем окно на весь экран
        self.root.attributes('-fullscreen', True)
        
        # Добавляем возможность выхода из полноэкранного режима по Escape
        self.root.bind('<Escape>', lambda e: self.root.attributes('-fullscreen', False))
        
        # Сохраняем начальные размеры окна
        self.initial_width = self.root.winfo_screenwidth()
        self.initial_height = self.root.winfo_screenheight()
        
        # Устанавливаем начальную прозрачность
        self.root.attributes('-alpha', 1.0)
        
        # Определяем цвета
        self.bg_dark_blue = "#0a192f"  # Темно-синий фон
        self.bg_blue = "#112240"       # Синий для карточек
        self.bg_light_blue = "#1d3461" # Светло-синий для активных элементов
        self.accent_blue = "#4a90e2"   # Акцентный синий
        self.hover_blue = "#357abd"    # Синий при наведении
        self.success_blue = "#2ecc71"  # Зеленый для успешных действий
        self.text_color = "#ffffff"    # Белый текст
        self.text_secondary = "#8892b0" # Серый текст
        self.hover_text_color = "#a8d1ff" # Светло-голубой текст при наведении
        self.border_color = "#4a90e2"  # Цвет обводки для кнопок управления
        
        # Устанавливаем строгую черную тему
        self.set_theme()
        
        # Устанавливаем иконку
        self.set_icon()
        
        # Настройки по умолчанию
        self.config = {
            "tlauncher_mods_path": "",
            "mods_repository_path": "",
            "tlauncher_exe_path": "",
            "enabled_mods": []
        }
        
        # Пути к папкам
        self.tlauncher_mods_path = tk.StringVar()
        self.mods_repository_path = tk.StringVar()
        self.tlauncher_exe_path = tk.StringVar()
        
        # Загрузить настройки, если они существуют
        self.load_config()
        
        # Пытаемся автоматически найти TLauncher
        if not self.tlauncher_exe_path.get():
            self.auto_find_tlauncher_exe()
            
        # Если нашли TLauncher, пытаемся определить папку mods
        if self.tlauncher_exe_path.get() and not self.tlauncher_mods_path.get():
            self.auto_find_mods_folder()
        
        # Создать интерфейс
        self.create_widgets()
        
        # Обновить список модов
        self.update_mod_list()

    def auto_find_tlauncher_exe(self):
        """Автоматический поиск exe-файла TLauncher в системе"""
        try:
            tlauncher_paths = []
            
            # Типичные места установки TLauncher
            possible_locations = []
            
            # Пользовательские папки
            user_folder = os.path.expanduser("~")
            possible_locations.extend([
                os.path.join(user_folder, "AppData", "Roaming", ".minecraft"),
                os.path.join(user_folder, "AppData", "Roaming", "TLauncher"),
                os.path.join(user_folder, "TLauncher"),
                os.path.join(user_folder, "Desktop", "TLauncher"),
                os.path.join(user_folder, "Downloads")
            ])
            
            # Системные папки
            if sys.platform.startswith('win'):
                program_files = [
                    os.environ.get('ProgramFiles', 'C:\\Program Files'),
                    os.environ.get('ProgramFiles(x86)', 'C:\\Program Files (x86)')
                ]
                for pf in program_files:
                    possible_locations.append(os.path.join(pf, "TLauncher"))
            
            # Проверяем все возможные места установки
            for location in possible_locations:
                if os.path.exists(location):
                    # Ищем exe-файлы в папке
                    for root, dirs, files in os.walk(location):
                        for file in files:
                            if file.lower().endswith(".exe") and "launcher" in file.lower():
                                full_path = os.path.join(root, file)
                                tlauncher_paths.append(full_path)
            
            # На диске C и D ищем по шаблону
            if sys.platform.startswith('win'):
                for drive in ['C:', 'D:']:
                    if os.path.exists(drive):
                        # Используем glob для поиска по шаблону
                        for pattern in ['*launcher*.exe', '*TLauncher*.exe']:
                            search_path = os.path.join(drive, '**', pattern)
                            try:
                                found_files = glob.glob(search_path, recursive=True)
                                tlauncher_paths.extend(found_files)
                            except:
                                # Игнорируем ошибки при слишком глубоком рекурсивном поиске
                                pass
            
            # Если нашли TLauncher, используем первый найденный путь
            if tlauncher_paths:
                # Сортируем пути, предпочитая те, где есть "TLauncher" в имени
                tlauncher_paths.sort(key=lambda x: 0 if "tlauncher" in os.path.basename(x).lower() else 1)
                self.tlauncher_exe_path.set(tlauncher_paths[0])
                print(f"Найден TLauncher: {tlauncher_paths[0]}")
                return True
            
            return False
            
        except Exception as e:
            print(f"Ошибка при поиске TLauncher: {e}")
            return False
    
    def auto_find_mods_folder(self):
        """Пытается найти папку mods на основе пути к TLauncher"""
        try:
            tlauncher_exe = self.tlauncher_exe_path.get()
            if not tlauncher_exe:
                return False
                
            # Возможные местоположения папки mods
            possible_mods_folders = []
            
            # 1. Рядом с .exe файлом
            exe_dir = os.path.dirname(tlauncher_exe)
            possible_mods_folders.append(os.path.join(exe_dir, "mods"))
            
            # 2. В .minecraft
            if ".minecraft" not in exe_dir:
                # Ищем папку .minecraft рядом с exe
                minecraft_dir = os.path.join(exe_dir, ".minecraft")
                if os.path.exists(minecraft_dir):
                    possible_mods_folders.append(os.path.join(minecraft_dir, "mods"))
            
            # 3. В AppData
            user_folder = os.path.expanduser("~")
            minecraft_appdata = os.path.join(user_folder, "AppData", "Roaming", ".minecraft")
            possible_mods_folders.append(os.path.join(minecraft_appdata, "mods"))
            
            # Проверяем все возможные папки
            for folder in possible_mods_folders:
                if os.path.exists(folder):
                    self.tlauncher_mods_path.set(folder)
                    print(f"Найдена папка модов: {folder}")
                    return True
            
            # Если папка не существует, создаем ее в .minecraft
            if os.path.exists(minecraft_appdata):
                mods_dir = os.path.join(minecraft_appdata, "mods")
                if not os.path.exists(mods_dir):
                    os.makedirs(mods_dir)
                self.tlauncher_mods_path.set(mods_dir)
                print(f"Создана папка модов: {mods_dir}")
                return True
                
            return False
            
        except Exception as e:
            print(f"Ошибка при поиске папки модов: {e}")
            return False
    
    def set_theme(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Глобальная настройка
        style.configure(".", 
                        background=self.bg_dark_blue,
                        foreground=self.text_color,
                        troughcolor=self.bg_blue,
                        fieldbackground=self.bg_blue,
                        borderwidth=0,
                        relief="flat")
        
        # Стиль для заголовка окна
        style.configure("WindowTitle.TLabel",
                        font=('Segoe UI', 12, 'bold'),  # Увеличили размер с 10 до 12 и добавили bold
                        foreground=self.text_color,
                        background=self.bg_blue)
        
        # Создаем простой темно-синий фон
        if PIL_AVAILABLE:
            try:
                # Создаем изображение с однородным цветом
                width = 1000
                height = 900
                image = Image.new('RGB', (width, height), self.bg_dark_blue)
                
                # Конвертируем в PhotoImage
                self.bg_image = ImageTk.PhotoImage(image)
                
                # Создаем фоновый лейбл
                self.bg_label = ttk.Label(self.root, image=self.bg_image)
                self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)
                
            except Exception as e:
                print(f"Ошибка при создании фона: {e}")
                # В случае ошибки используем простой цветной фон
                self.root.configure(background=self.bg_dark_blue)
        
        # Стили для кнопок управления
        style.configure("Control.TButton",
                        background=self.bg_blue,
                        foreground=self.text_color,
                        borderwidth=2,
                        relief="solid",
                        padding=10,
                        font=('Segoe UI', 10))
        
        style.configure("Control.Hover.TButton",
                        background=self.hover_blue,
                        foreground=self.hover_text_color,
                        borderwidth=2,
                        relief="solid",
                        font=('Segoe UI', 10, 'bold'))
        
        # Стиль для главной кнопки запуска
        style.configure("Launch.TButton",
                        background=self.accent_blue,
                        foreground=self.text_color, 
                        borderwidth=0,
                        relief="flat",
                        font=('Segoe UI', 12, 'bold'),
                        padding=15)
        
        style.configure("Launch.Hover.TButton",
                        background=self.hover_blue,
                        foreground=self.hover_text_color,
                        borderwidth=0,
                        relief="flat",
                        font=('Segoe UI', 12, 'bold'),
                        padding=15)
        
        # Стили для фреймов
        style.configure("Card.TFrame",
                        background=self.bg_blue,
                        borderwidth=0,
                        relief="flat")
        
        # Стили для меток
        style.configure("Title.TLabel",
                        font=('Segoe UI', 24, 'bold'),
                        foreground=self.text_color,
                        background=self.bg_dark_blue)
        
        style.configure("Subtitle.TLabel",
                        font=('Segoe UI', 12),
                        foreground=self.text_secondary,
                        background=self.bg_dark_blue)
        
        # Стили для полей ввода
        style.configure("TEntry",
                        fieldbackground=self.bg_blue,
                        foreground=self.text_color,
                        borderwidth=0,
                        relief="flat",
                        padding=5)
        
        # Стили для Treeview
        style.configure("Treeview", 
                        background=self.bg_blue,
                        foreground=self.text_color, 
                        fieldbackground=self.bg_blue,
                        borderwidth=0,
                        relief="flat")
        
        style.configure("Treeview.Heading", 
                        background=self.bg_light_blue,
                        foreground=self.text_color, 
                        borderwidth=0,
                        relief="flat")
        
        style.map("Treeview",
                  background=[('selected', self.accent_blue)],
                  foreground=[('selected', self.hover_text_color)])
        
        # Стиль для чекбоксов
        style.configure("TCheckbutton",
                        background=self.bg_dark_blue,
                        foreground=self.text_color,
                        borderwidth=0,
                        relief="flat")
        
        style.map("TCheckbutton",
                  background=[('active', self.bg_dark_blue)],
                  indicatorcolor=[('selected', self.success_blue), ('!selected', self.bg_blue)])
        
        # Устанавливаем фоновый цвет для главного окна
        self.root.configure(background=self.bg_dark_blue)

    def set_icon(self):
        # Устанавливаем иконку из файла
        if PIL_AVAILABLE:
            try:
                icon_path = os.path.join("resources", "resources", "icon.png")
                print(f"Пытаемся установить иконку из: {os.path.abspath(icon_path)}")
                
                if os.path.exists(icon_path):
                    print("Файл иконки найден")
                    icon_image = Image.open(icon_path)
                    print(f"Размер оригинальной иконки: {icon_image.size}")
                    
                    # Конвертируем в RGBA если нужно
                    if icon_image.mode != 'RGBA':
                        icon_image = icon_image.convert('RGBA')
                    
                    # Создаем иконку для панели задач (32x32)
                    taskbar_icon = icon_image.resize((32, 32), Image.LANCZOS)
                    self.taskbar_icon = ImageTk.PhotoImage(taskbar_icon)
                    print("Иконка для панели задач создана")
                    
                    # Создаем иконку для окна (16x16)
                    window_icon = icon_image.resize((16, 16), Image.LANCZOS)
                    self.window_icon = ImageTk.PhotoImage(window_icon)
                    print("Иконка для окна создана")
                    
                    # Создаем иконку для панели задач (256x256)
                    large_icon = icon_image.resize((256, 256), Image.LANCZOS)
                    self.large_icon = ImageTk.PhotoImage(large_icon)
                    print("Большая иконка создана")
                    
                    # Устанавливаем иконку для окна и панели задач
                    self.root.iconphoto(True, self.taskbar_icon, self.window_icon, self.large_icon)
                    print("Иконки установлены")
                    
                    # Устанавливаем иконку для панели задач Windows
                    if sys.platform.startswith('win'):
                        try:
                            import ctypes
                            myappid = 'wargonlauncher.2.2'  # Уникальный идентификатор приложения
                            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
                            print("Идентификатор приложения установлен")
                        except Exception as e:
                            print(f"Ошибка при установке идентификатора приложения: {e}")
                else:
                    print(f"Файл иконки не найден: {icon_path}")
            except Exception as e:
                print(f"Ошибка при установке иконки: {str(e)}")
                import traceback
                traceback.print_exc()
    
    def create_widgets(self):
        # Создаем собственную панель управления
        title_bar = ttk.Frame(self.root, style="Card.TFrame")
        title_bar.pack(fill="x", side="top")
        
        # Добавляем возможность перетаскивания окна
        title_bar.bind('<Button-1>', self.start_move)
        title_bar.bind('<B1-Motion>', self.on_move)
        
        # Добавляем логотип в панель
        if PIL_AVAILABLE:
            try:
                # Загружаем иконку из файла
                icon_path = os.path.join("resources", "resources", "icon.png")
                print(f"Пытаемся загрузить иконку из: {os.path.abspath(icon_path)}")
                
                if os.path.exists(icon_path):
                    print("Файл иконки найден")
                    icon = Image.open(icon_path)
                    print(f"Размер оригинальной иконки: {icon.size}")
                    
                    # Конвертируем в RGBA если нужно
                    if icon.mode != 'RGBA':
                        icon = icon.convert('RGBA')
                    
                    icon = icon.resize((24, 24), Image.LANCZOS)
                    print(f"Размер после изменения: {icon.size}")
                    
                    self.title_icon = ImageTk.PhotoImage(icon)
                    print("Иконка успешно создана")
                    
                    icon_label = ttk.Label(title_bar, image=self.title_icon, background=self.bg_blue)
                    icon_label.pack(side="left", padx=(10, 5))
                    print("Иконка добавлена в панель")
                else:
                    print(f"Файл иконки не найден: {icon_path}")
            except Exception as e:
                print(f"Ошибка при добавлении иконки в панель: {str(e)}")
                import traceback
                traceback.print_exc()
        
        # Заголовок окна
        title_label = ttk.Label(title_bar,
                              text="WargonLauncher [2.2]",
                              style="WindowTitle.TLabel")
        title_label.pack(side="left", padx=10, pady=2)
        
        # Кнопки управления окном
        buttons_frame = ttk.Frame(title_bar, style="Card.TFrame")
        buttons_frame.pack(side="right", padx=5)
        
        # Кнопка свернуть
        minimize_button = ModernButton(buttons_frame,
                                     text="─",
                                     hover_text="─",
                                     command=self.animate_minimize,
                                     style="Control.TButton")
        minimize_button.pack(side="left", padx=2)
        
        # Кнопка закрыть
        close_button = ModernButton(buttons_frame,
                                  text="✕",
                                  hover_text="✕",
                                  command=self.animate_close,
                                  style="Control.TButton")
        close_button.pack(side="left", padx=2)
        
        # Создаем основной контейнер с отступами
        main_container = ttk.Frame(self.root, style="Card.TFrame")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Заголовок
        title_frame = ttk.Frame(main_container)
        title_frame.pack(fill="x", pady=(0, 20))
        
        # Добавляем иконку мода
        if PIL_AVAILABLE:
            try:
                mod_icon_data = base64.b64decode(MOD_ICON_BASE64)
                mod_icon = Image.open(BytesIO(mod_icon_data))
                mod_icon = mod_icon.resize((48, 48), Image.LANCZOS)
                self.mod_icon_image = ImageTk.PhotoImage(mod_icon)
                
                mod_icon_label = ttk.Label(title_frame, image=self.mod_icon_image)
                mod_icon_label.pack(side="left", padx=(0, 10))
            except Exception as e:
                print(f"Ошибка при добавлении иконки мода: {e}")
        
        title_label = ttk.Label(title_frame, 
                              text="🎮 WargonLauncher [2.2]",
                              style="Title.TLabel")
        title_label.pack(side="left")
        
        subtitle_label = ttk.Label(title_frame,
                                 text="✨ Менеджер модов для Minecraft",
                                 style="Subtitle.TLabel")
        subtitle_label.pack(side="left", padx=(10, 0), pady=(5, 0))
        
        # Верхняя панель настроек с отступами и разделителем
        settings_frame = ttk.LabelFrame(main_container, 
                                      text="⚙️ Настройки",
                                      style="Card.TFrame")
        settings_frame.pack(fill="x", pady=(0, 20), padx=5)
        
        # Добавляем разделитель после настроек с надписью
        separator_frame = ttk.Frame(main_container, style="Card.TFrame")
        separator_frame.pack(fill='x', pady=(0, 20))
        
        # Левая линия разделителя
        left_separator = ttk.Separator(separator_frame, orient='horizontal')
        left_separator.pack(side='left', fill='x', expand=True, padx=(0, 10))
        
        # Надпись на разделителе
        separator_label = ttk.Label(separator_frame,
                                  text="📦 Список модов",
                                  style="Subtitle.TLabel",
                                  background=self.bg_dark_blue)
        separator_label.pack(side='left', padx=10)
        
        # Правая линия разделителя
        right_separator = ttk.Separator(separator_frame, orient='horizontal')
        right_separator.pack(side='left', fill='x', expand=True, padx=(10, 0))
        
        # Путь к модам Tlauncher
        path_frame = ttk.Frame(settings_frame, style="Card.TFrame")
        path_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(path_frame, 
                 text="📂 Путь к папке mods Tlauncher:",
                 style="Subtitle.TLabel").pack(side="left")
        
        ttk.Entry(path_frame,
                 textvariable=self.tlauncher_mods_path,
                 width=50).pack(side="left", padx=10)
        
        ModernButton(path_frame,
                    text="🔍 Обзор",
                    hover_text="🔍 Выбрать папку",
                    command=self.browse_tlauncher_path,
                    style="Control.TButton").pack(side="left")
        
        # Путь к репозиторию модов
        repo_frame = ttk.Frame(settings_frame, style="Card.TFrame")
        repo_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(repo_frame,
                 text="📦 Путь к вашей папке с модами:",
                 style="Subtitle.TLabel").pack(side="left")
        
        ttk.Entry(repo_frame,
                 textvariable=self.mods_repository_path,
                 width=50).pack(side="left", padx=10)
        
        ModernButton(repo_frame,
                    text="🔍 Обзор",
                    hover_text="🔍 Выбрать папку",
                    command=self.browse_repository_path,
                    style="Control.TButton").pack(side="left")
        
        # Путь к Tlauncher.exe
        exe_frame = ttk.Frame(settings_frame, style="Card.TFrame")
        exe_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(exe_frame,
                 text="🎯 Путь к Tlauncher.exe:",
                 style="Subtitle.TLabel").pack(side="left")
        
        ttk.Entry(exe_frame,
                 textvariable=self.tlauncher_exe_path,
                 width=50).pack(side="left", padx=10)
        
        buttons_frame = ttk.Frame(exe_frame, style="Card.TFrame")
        buttons_frame.pack(side="left")
        
        ModernButton(buttons_frame,
                    text="🔍 Обзор",
                    hover_text="🔍 Выбрать файл",
                    command=self.browse_tlauncher_exe,
                    style="Control.TButton").pack(side="left", padx=2)
        
        ModernButton(buttons_frame,
                    text="🔎 Автопоиск",
                    hover_text="🔎 Найти автоматически",
                    command=self.auto_detect_tlauncher,
                    style="Control.TButton").pack(side="left", padx=2)
        
        # Кнопка сохранения настроек
        ModernButton(settings_frame,
                    text="💾 Сохранить настройки",
                    hover_text="💾 Сохранить изменения",
                    command=self.save_config,
                    style="Control.TButton").pack(pady=10)
        
        # Фрейм со списком модов с отдельным фоном
        mods_frame = ttk.LabelFrame(main_container,
                                  text="📋 Доступные моды",
                                  style="Card.TFrame")
        mods_frame.pack(fill="both", expand=True, pady=(0, 20), padx=5)
        
        # Добавляем внутренний фрейм для списка модов с отступами
        mods_inner_frame = ttk.Frame(mods_frame, style="Card.TFrame")
        mods_inner_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Список модов с чекбоксами
        self.mods_listbox = ttk.Treeview(mods_inner_frame,
                                       columns=("name", "enabled"),
                                       show="headings",
                                       style="Treeview")
        self.mods_listbox.heading("name", text="📦 Название мода")
        self.mods_listbox.heading("enabled", text="✅ Включен")
        self.mods_listbox.column("name", width=400)
        self.mods_listbox.column("enabled", width=100, anchor="center")
        
        # Добавляем скроллбар
        scrollbar = ttk.Scrollbar(mods_inner_frame,
                                orient="vertical",
                                command=self.mods_listbox.yview)
        self.mods_listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.mods_listbox.pack(fill="both", expand=True)
        
        # Кнопки выбора модов
        mod_buttons_frame = ttk.Frame(mods_frame, style="Card.TFrame")
        mod_buttons_frame.pack(fill="x", padx=5, pady=5)
        
        ModernButton(mod_buttons_frame,
                    text="✅ Выбрать все",
                    hover_text="✅ Включить все моды",
                    command=self.select_all_mods,
                    style="Control.TButton").pack(side="left", padx=5)
        
        ModernButton(mod_buttons_frame,
                    text="❌ Снять выбор",
                    hover_text="❌ Отключить все моды",
                    command=self.deselect_all_mods,
                    style="Control.TButton").pack(side="left", padx=5)
        
        ModernButton(mod_buttons_frame,
                    text="🔄 Обновить список",
                    hover_text="🔄 Обновить список модов",
                    command=self.update_mod_list,
                    style="Control.TButton").pack(side="left", padx=5)
        
        ModernButton(mod_buttons_frame,
                    text="📥 Показать установленные моды",
                    hover_text="📥 Просмотр установленных модов",
                    command=self.show_installed_mods,
                    style="Control.TButton").pack(side="left", padx=5)
        
        # Кнопка запуска
        launch_frame = ttk.Frame(self.root, style="Card.TFrame")
        launch_frame.pack(fill="x", padx=20, pady=(0, 20))
        
        launch_button = ModernButton(launch_frame,
                                   text="🎮 ЗАПУСТИТЬ ИГРУ",
                                   hover_text="🎮 НАЧАТЬ ИГРУ",
                                   command=self.launch_game,
                                   style="Launch.TButton")
        launch_button.pack(fill="x", expand=True)
        
        # Статус
        status_frame = ttk.Frame(self.root, style="Card.TFrame")
        status_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        self.status_var = tk.StringVar()
        self.status_var.set("✨ Готов к запуску")
        status_bar = ttk.Label(status_frame,
                             textvariable=self.status_var,
                             relief="flat",
                             anchor="w",
                             style="Subtitle.TLabel")
        status_bar.pack(side="left", fill="x", expand=True)
        
        # Добавляем надпись с информацией о разработчике
        author_label = ttk.Label(status_frame, 
                               text="👨‍💻 Launcher by @https://t.me/cprojectru", 
                               style="Subtitle.TLabel",
                               anchor="e")
        author_label.pack(side="right", padx=5)

    def load_config(self):
        # Загрузить настройки из файла конфигурации
        try:
            if os.path.exists("wargonlauncher_config.json"):
                with open("wargonlauncher_config.json", "r", encoding="utf-8") as f:
                    self.config = json.load(f)
                
                self.tlauncher_mods_path.set(self.config.get("tlauncher_mods_path", ""))
                self.mods_repository_path.set(self.config.get("mods_repository_path", ""))
                self.tlauncher_exe_path.set(self.config.get("tlauncher_exe_path", ""))
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить конфигурацию: {str(e)}")
    
    def save_config(self):
        # Сохранить настройки в файл конфигурации
        try:
            self.config["tlauncher_mods_path"] = self.tlauncher_mods_path.get()
            self.config["mods_repository_path"] = self.mods_repository_path.get()
            self.config["tlauncher_exe_path"] = self.tlauncher_exe_path.get()
            
            # Сохраняем выбранные моды
            self.config["enabled_mods"] = []
            for item_id in self.mods_listbox.get_children():
                mod_name = self.mods_listbox.item(item_id)["values"][0]
                is_enabled = self.mods_listbox.item(item_id)["values"][1] == "Да"
                if is_enabled:
                    self.config["enabled_mods"].append(mod_name)
            
            with open("wargonlauncher_config.json", "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=4)
            
            self.status_var.set("Настройки сохранены успешно")
            messagebox.showinfo("Успех", "Настройки сохранены")
        except Exception as e:
            self.status_var.set(f"Ошибка при сохранении: {str(e)}")
            messagebox.showerror("Ошибка", f"Не удалось сохранить конфигурацию: {str(e)}")
    
    def browse_tlauncher_path(self):
        # Выбрать папку модов Tlauncher
        path = filedialog.askdirectory(title="Выберите папку mods Tlauncher")
        if path:
            self.tlauncher_mods_path.set(path)
    
    def browse_repository_path(self):
        # Выбрать папку репозитория модов
        path = filedialog.askdirectory(title="Выберите вашу папку с модами")
        if path:
            self.mods_repository_path.set(path)
            # Обновляем список модов в соответствии с новым выбранным путем
            self.update_mod_list()
    
    def browse_tlauncher_exe(self):
        # Выбрать исполняемый файл Tlauncher
        path = filedialog.askopenfilename(
            title="Выберите исполняемый файл Tlauncher",
            filetypes=[("Executable files", "*.exe"), ("All files", "*.*")]
        )
        if path:
            self.tlauncher_exe_path.set(path)
    
    def auto_detect_tlauncher(self):
        # Автоматически обнаружить Tlauncher
        if self.auto_find_tlauncher_exe():
            self.status_var.set(f"TLauncher найден: {self.tlauncher_exe_path.get()}")
            if not self.tlauncher_mods_path.get():
                self.auto_find_mods_folder()
                if self.tlauncher_mods_path.get():
                    self.status_var.set(f"TLauncher и папка модов найдены автоматически")
        else:
            self.status_var.set("TLauncher не найден. Укажите путь вручную.")
            messagebox.showwarning("Предупреждение", "TLauncher не найден. Пожалуйста, укажите путь вручную.")
    
    def update_mod_list(self):
        # Обновить список модов из репозитория
        self.mods_listbox.delete(*self.mods_listbox.get_children())
        
        repo_path = self.mods_repository_path.get()
        if not repo_path or not os.path.exists(repo_path):
            self.status_var.set("Пожалуйста, укажите действительную папку с модами")
            return
        
        # Загружаем список JAR-файлов из репозитория модов
        try:
            mod_files = []
            for file in os.listdir(repo_path):
                if file.lower().endswith('.jar'):
                    mod_files.append(file)
            
            # Добавляем моды в список
            for mod_file in mod_files:
                # Проверяем, был ли мод включен ранее
                is_enabled = mod_file in self.config.get("enabled_mods", [])
                
                self.mods_listbox.insert("", "end", values=(mod_file, "Да" if is_enabled else "Нет"))
            
            # Добавляем обработчик клика для переключения статуса
            self.mods_listbox.bind('<Double-1>', self.toggle_mod_status)
            
            self.status_var.set(f"Найдено {len(mod_files)} модов")
        except Exception as e:
            self.status_var.set(f"Ошибка при обновлении списка модов: {str(e)}")
            messagebox.showerror("Ошибка", f"Не удалось загрузить список модов: {str(e)}")
    
    def toggle_mod_status(self, event):
        # Переключить статус мода (включен/выключен)
        selected_item = self.mods_listbox.selection()
        if not selected_item:
            return
        
        item_id = selected_item[0]
        values = self.mods_listbox.item(item_id)["values"]
        mod_name = values[0]
        current_status = values[1]
        
        # Переключаем статус
        new_status = "Нет" if current_status == "Да" else "Да"
        self.mods_listbox.item(item_id, values=(mod_name, new_status))
    
    def select_all_mods(self):
        # Выбрать все моды
        for item_id in self.mods_listbox.get_children():
            mod_name = self.mods_listbox.item(item_id)["values"][0]
            self.mods_listbox.item(item_id, values=(mod_name, "Да"))
        self.status_var.set("Все моды выбраны")
    
    def deselect_all_mods(self):
        # Снять выбор со всех модов
        for item_id in self.mods_listbox.get_children():
            mod_name = self.mods_listbox.item(item_id)["values"][0]
            self.mods_listbox.item(item_id, values=(mod_name, "Нет"))
        self.status_var.set("Выбор снят со всех модов")
    
    def launch_game(self):
        # Копируем выбранные моды и запускаем игру
        self.status_var.set("Запуск игры...")
        
        # Проверяем настройки
        tlauncher_mods_path = self.tlauncher_mods_path.get()
        mods_repository_path = self.mods_repository_path.get()
        tlauncher_exe_path = self.tlauncher_exe_path.get()
        
        if not tlauncher_mods_path or not os.path.exists(tlauncher_mods_path):
            self.status_var.set("Ошибка: Папка модов Tlauncher не указана или не существует")
            messagebox.showerror("Ошибка", "Пожалуйста, укажите действительную папку модов Tlauncher")
            return
        
        if not mods_repository_path or not os.path.exists(mods_repository_path):
            self.status_var.set("Ошибка: Папка с вашими модами не указана или не существует")
            messagebox.showerror("Ошибка", "Пожалуйста, укажите действительную папку с вашими модами")
            return
        
        if self.auto_launch.get() and (not tlauncher_exe_path or not os.path.exists(tlauncher_exe_path)):
            self.status_var.set("Ошибка: Исполняемый файл Tlauncher не указан или не существует")
            messagebox.showerror("Ошибка", "Пожалуйста, укажите действительный путь к Tlauncher.exe")
            return
        
        # Создаем поток для копирования файлов и запуска игры
        thread = Thread(target=self._copy_mods_and_launch)
        thread.daemon = True
        thread.start()
    
    def _copy_mods_and_launch(self):
        """Копирование модов и запуск игры в отдельном потоке"""
        try:
            # Очищаем папку модов Tlauncher
            tlauncher_mods_path = self.tlauncher_mods_path.get()
            mods_repository_path = self.mods_repository_path.get()
            tlauncher_exe_path = self.tlauncher_exe_path.get()
            
            # Создаем папку mods, если её нет
            if not os.path.exists(tlauncher_mods_path):
                os.makedirs(tlauncher_mods_path)
            
            # Удаляем все существующие моды
            for file in os.listdir(tlauncher_mods_path):
                if file.lower().endswith('.jar'):
                    file_path = os.path.join(tlauncher_mods_path, file)
                    try:
                        os.remove(file_path)
                    except:
                        pass
            
            # Копируем выбранные моды
            copied_count = 0
            for item_id in self.mods_listbox.get_children():
                values = self.mods_listbox.item(item_id)["values"]
                mod_name = values[0]
                is_enabled = values[1] == "Да"
                
                if is_enabled:
                    src = os.path.join(mods_repository_path, mod_name)
                    dst = os.path.join(tlauncher_mods_path, mod_name)
                    shutil.copy2(src, dst)
                    copied_count += 1
            
            # Обновляем статус
            self.status_var.set(f"Скопировано {copied_count} модов в Tlauncher")
            
            # Сохраняем настройки   WWWWWWWWWWWWWWWWWWWWWWWW 
            self.save_config()
            
            # Запускаем Tlauncher, если включена соответствующая опция
            if self.auto_launch.get() and tlauncher_exe_path:
                self.status_var.set(f"Запуск Tlauncher: {tlauncher_exe_path}")
                subprocess.Popen([tlauncher_exe_path])
        
        except Exception as e:
            self.status_var.set(f"Ошибка при запуске: {str(e)}")
            messagebox.showerror("Ошибка", f"Произошла ошибка при запуске игры: {str(e)}")

    def show_installed_mods(self):
        """Показать моды, которые уже установлены в папке mods TLauncher"""
        tlauncher_mods_path = self.tlauncher_mods_path.get()
        
        if not tlauncher_mods_path or not os.path.exists(tlauncher_mods_path):
            messagebox.showerror("Ошибка", "Папка модов TLauncher не указана или не существует")
            return
            
        try:
            installed_mods = []
            for file in os.listdir(tlauncher_mods_path):
                if file.lower().endswith('.jar'):
                    installed_mods.append(file)
            
            if not installed_mods:
                messagebox.showinfo("Информация", "В папке модов TLauncher нет установленных модов")
                return
                
            # Создаем окно со списком модов
            mods_window = tk.Toplevel(self.root)
            mods_window.title("Установленные моды")
            mods_window.geometry("400x300")
            mods_window.configure(background="#000000")
            
            # Создаем список модов
            mods_list = ttk.Treeview(mods_window, columns=("name",), show="headings")
            mods_list.heading("name", text="Название мода")
            mods_list.column("name", width=380)
            
            # Добавляем скроллбар
            scrollbar = ttk.Scrollbar(mods_window, orient="vertical", command=mods_list.yview)
            mods_list.configure(yscrollcommand=scrollbar.set)
            
            # Размещаем элементы
            scrollbar.pack(side="right", fill="y")
            mods_list.pack(fill="both", expand=True, padx=5, pady=5)
            
            # Добавляем моды в список
            for mod in installed_mods:
                mods_list.insert("", "end", values=(mod,))
                
            # Добавляем кнопку закрытия
            close_button = ttk.Button(mods_window, text="Закрыть", command=mods_window.destroy)
            close_button.pack(pady=5)
            
            # Устанавливаем фокус на окно
            mods_window.focus_set()
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось получить список установленных модов: {str(e)}")

    def start_move(self, event):
        """Начало перетаскивания окна"""
        self.x = event.x
        self.y = event.y

    def on_move(self, event):
        """Перетаскивание окна"""
        deltax = event.x - self.x
        deltay = event.y - self.y
        x = self.root.winfo_x() + deltax
        y = self.root.winfo_y() + deltay
        self.root.geometry(f"+{x}+{y}")

    def animate_minimize(self):
        """Плавная анимация сворачивания окна с эффектом затухания"""
        # Количество шагов анимации
        steps = 10  # Уменьшили с 20 до 10
        
        def fade_step(step):
            if step < steps:
                # Вычисляем новую прозрачность
                alpha = 1.0 - (step / steps)
                self.root.attributes('-alpha', alpha)
                
                # Планируем следующий шаг
                self.root.after(10, lambda: fade_step(step + 1))  # Уменьшили с 20 до 10
            else:
                # После завершения анимации сворачиваем окно
                self.root.iconify()
                # Восстанавливаем прозрачность при разворачивании
                self.root.bind('<Map>', self.restore_alpha)
        
        # Запускаем анимацию
        fade_step(0)
    
    def restore_alpha(self, event=None):
        """Восстановление прозрачности окна при разворачивании"""
        # Количество шагов анимации
        steps = 10  # Уменьшили с 20 до 10
        
        def fade_in_step(step):
            if step < steps:
                # Вычисляем новую прозрачность
                alpha = step / steps
                self.root.attributes('-alpha', alpha)
                
                # Планируем следующий шаг
                self.root.after(10, lambda: fade_in_step(step + 1))  # Уменьшили с 20 до 10
            else:
                # Устанавливаем полную непрозрачность
                self.root.attributes('-alpha', 1.0)
                self.root.unbind('<Map>')  # Удаляем привязку после использования
        
        # Запускаем анимацию
        fade_in_step(0)

    def animate_close(self):
        """Плавная анимация закрытия окна с эффектом затухания"""
        # Количество шагов анимации
        steps = 10  # Уменьшили с 20 до 10
        
        def fade_step(step):
            if step < steps:
                # Вычисляем новую прозрачность
                alpha = 1.0 - (step / steps)
                self.root.attributes('-alpha', alpha)
                
                # Планируем следующий шаг
                self.root.after(10, lambda: fade_step(step + 1))  # Уменьшили с 20 до 10
            else:
                # После завершения анимации закрываем окно
                self.root.destroy()
        
        # Запускаем анимацию
        fade_step(0)

# Запуск приложения
if __name__ == "__main__":
    root = tk.Tk()
    app = PolLauncher(root)
    root.mainloop()
