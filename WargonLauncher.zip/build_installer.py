import os
import subprocess
import shutil
import sys

def build_installer():
    # Устанавливаем PyInstaller если его нет
    try:
        import PyInstaller
    except ImportError:
        print("Установка PyInstaller...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Очищаем папку build если она есть
    if os.path.exists("build"):
        shutil.rmtree("build")
    if os.path.exists("dist"):
        shutil.rmtree("dist")
    
    # Компилируем установщик
    print("Компиляция установщика...")
    subprocess.run([
        "pyinstaller",
        "--noconfirm",
        "--onefile",
        "--windowed",
        "--name=WargonLauncher_Setup",
        "installer.py"
    ])
    
    print("Установщик скомпилирован в dist/WargonLauncher_Setup.exe")

if __name__ == "__main__":
    build_installer() 