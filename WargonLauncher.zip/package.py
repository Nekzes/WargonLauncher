import os
import base64
import zipfile
from io import BytesIO

def package_app():
    # Создаем временный zip-архив
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Добавляем все файлы приложения
        for root, dirs, files in os.walk('.'):
            for file in files:
                if file.endswith('.py') or file.endswith('.exe') or file.endswith('.png') or file.endswith('.ico'):
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, '.')
                    zip_file.write(file_path, arcname)
    
    # Конвертируем zip в base64
    zip_data = zip_buffer.getvalue()
    zip_base64 = base64.b64encode(zip_data).decode('utf-8')
    
    # Создаем файл с закодированными данными
    with open('app_data.py', 'w', encoding='utf-8') as f:
        f.write('APP_DATA = """\n')
        f.write(zip_base64)
        f.write('"""\n')

if __name__ == "__main__":
    package_app() 