from PIL import Image
import os

def convert_to_ico():
    # Путь к PNG иконке
    png_path = os.path.join("resources", "resources", "icon.png")
    # Путь для сохранения ICO файла
    ico_path = os.path.join("resources", "resources", "icon.ico")
    
    try:
        # Открываем PNG изображение
        img = Image.open(png_path)
        
        # Конвертируем в RGBA если нужно
        if img.mode != 'RGBA':
            img = img.convert('RGBA')
        
        # Создаем иконку с разными размерами
        sizes = [(16,16), (32,32), (48,48), (64,64), (128,128), (256,256)]
        img.save(ico_path, format='ICO', sizes=sizes)
        print(f"Иконка успешно сконвертирована и сохранена в {ico_path}")
    except Exception as e:
        print(f"Ошибка при конвертации иконки: {e}")

if __name__ == "__main__":
    convert_to_ico() 