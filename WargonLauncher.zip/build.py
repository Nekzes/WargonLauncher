import os
import subprocess
import shutil
import sys

def build_exe():
    # Устанавливаем PyInstaller если его нет
    try:
        import PyInstaller
    except ImportError:
        print("Установка PyInstaller...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Очищаем папку build если она есть
    if os.path.exists("build"):
        shutil.rmtree("build")
    if os.path.exists("dist"):
        shutil.rmtree("dist")
    
    # Компилируем лаунчер
    print("Компиляция лаунчера...")
    subprocess.run([
        "pyinstaller",
        "--noconfirm",
        "--onefile",
        "--windowed",
        "--icon=resources/resources/icon.ico",
        "--add-data=resources;resources",
        "--name=WargonLauncher",
        "sourse.py"
    ])
    
    print("Лаунчер скомпилирован в dist/WargonLauncher.exe")

if __name__ == "__main__":
    build_exe() 